import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.lightBlue,
        appBar: AppBar(
          title: Text("Hey!"),
          backgroundColor: const Color.fromARGB(255, 220, 131, 131),
        ),
        body: Center(
          child: Image(
            image: AssetImage(
              'images/star.jpg')
            ),
        ),
      ),
    )
  );
}