import 'package:flutter/material.dart';

import '../models/item_model.dart';
import 'stock_status.dart';

class ItemCard extends StatelessWidget {

  final ItemModel item;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const ItemCard({
    super.key,
    required this.item,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {

    return Card(
      elevation: 3,

      margin: const EdgeInsets.only(
        bottom: 12,
      ),

      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),

      child: Padding(
        padding: const EdgeInsets.all(12),

        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,

          children: [

            Row(
              mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,

              children: [

                Expanded(
                  child: Text(
                    item.namaBarang,

                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                StockStatus(
                  stok: item.stok,
                ),
              ],
            ),

            const SizedBox(height: 10),

            Text(
              'Kategori: ${item.kategori}',
            ),

            Text(
              'Rak: ${item.lokasiRak}',
            ),

            Text(item.deskripsi),

            const SizedBox(height: 10),

            Row(
              mainAxisAlignment:
                  MainAxisAlignment.end,

              children: [

                IconButton(
                  onPressed: onEdit,

                  icon: const Icon(
                    Icons.edit,
                  ),
                ),

                IconButton(
                  onPressed: onDelete,

                  icon: const Icon(
                    Icons.delete,
                    color: Colors.red,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}