import 'package:flutter/material.dart';

class StockStatus extends StatelessWidget {

  final int stok;

  const StockStatus({
    super.key,
    required this.stok,
  });

  Color getStatusColor() {

    if (stok <= 3) {
      return Colors.red;
    }

    if (stok <= 10) {
      return Colors.orange;
    }

    return Colors.green;
  }

  @override
  Widget build(BuildContext context) {

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),

      decoration: BoxDecoration(
        color: getStatusColor(),
        borderRadius: BorderRadius.circular(10),
      ),

      child: Text(
        'Stok: $stok',
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}