class ItemModel {
  final int id;
  final String namaBarang;
  final String kategori;
  final int stok;
  final String lokasiRak;
  final String deskripsi;

  ItemModel({
    required this.id,
    required this.namaBarang,
    required this.kategori,
    required this.stok,
    required this.lokasiRak,
    required this.deskripsi,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'namaBarang': namaBarang,
      'kategori': kategori,
      'stok': stok,
      'lokasiRak': lokasiRak,
      'deskripsi': deskripsi,
    };
  }

  factory ItemModel.fromMap(Map<String, dynamic> map) {
    return ItemModel(
      id: map['id'],
      namaBarang: map['namaBarang'],
      kategori: map['kategori'],
      stok: map['stok'],
      lokasiRak: map['lokasiRak'],
      deskripsi: map['deskripsi'],
    );
  }
}