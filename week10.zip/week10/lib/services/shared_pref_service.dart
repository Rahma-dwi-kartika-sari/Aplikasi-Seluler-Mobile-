import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/item_model.dart';

class SharedPrefService {

  static const String key = 'warehouse_items';

  // Simpan data
  static Future<void> saveItems(List<ItemModel> items) async {

    SharedPreferences prefs =
        await SharedPreferences.getInstance();

    List<String> itemList = items.map((item) {
      return jsonEncode(item.toMap());
    }).toList();

    await prefs.setStringList(key, itemList);
  }

  // Ambil data
  static Future<List<ItemModel>> loadItems() async {

    SharedPreferences prefs =
        await SharedPreferences.getInstance();

    List<String>? data = prefs.getStringList(key);

    if (data == null) {
      return [];
    }

    return data.map((item) {
      return ItemModel.fromMap(
        jsonDecode(item),
      );
    }).toList();
  }
}