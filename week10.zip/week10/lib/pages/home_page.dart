import 'package:flutter/material.dart';

import '../models/item_model.dart';
import '../services/shared_pref_service.dart';
import '../widgets/item_card.dart';
import '../widgets/search_bar.dart';

import 'add_item_page.dart';
import 'edit_item_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  List<ItemModel> itemList = [];
  List<ItemModel> filteredList = [];

  TextEditingController searchController =
      TextEditingController();

  String selectedSort = 'Semua';

  @override
  void initState() {
    super.initState();
    loadItems();
  }

  // Load data
  Future<void> loadItems() async {

    List<ItemModel> data =
        await SharedPrefService.loadItems();

    setState(() {
      itemList = data;
      filteredList = data;
    });
  }

  // Search barang
  void searchItems(String keyword) {

    List<ItemModel> results = [];

    if (keyword.isEmpty) {

      results = itemList;

    } else {

      results = itemList.where((item) {

        return item.namaBarang
                .toLowerCase()
                .contains(keyword.toLowerCase()) ||

            item.kategori
                .toLowerCase()
                .contains(keyword.toLowerCase());

      }).toList();
    }

    setState(() {
      filteredList = results;
    });
  }

  // Sorting
  void sortItems(String value) {

    List<ItemModel> sortedList = [];

    if (value == 'Semua') {

      sortedList = itemList;

    } else if (value == 'Stok Sedikit') {

      sortedList = itemList.where((item) {
        return item.stok <= 10;
      }).toList();

    } else {

      sortedList = itemList.where((item) {
        return item.kategori == value;
      }).toList();
    }

    setState(() {
      selectedSort = value;
      filteredList = sortedList;
    });
  }

  // Hapus barang
  void deleteItem(ItemModel item) async {

    bool? confirm = await showDialog(
      context: context,

      builder: (context) {

        return AlertDialog(
          title: const Text('Konfirmasi'),

          content: const Text(
            'Apakah kamu yakin ingin menghapus barang ini?',
          ),

          actions: [

            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },

              child: const Text('Batal'),
            ),

            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },

              child: const Text('Hapus'),
            ),
          ],
        );
      },
    );

    if (confirm == true) {

      setState(() {

        itemList.removeWhere((data) {
          return data.id == item.id;
        });

        filteredList = itemList;
      });

      await SharedPrefService.saveItems(itemList);
    }
  }

  // Total stok menipis
  int getLowStockCount() {

    return itemList.where((item) {
      return item.stok <= 10;
    }).length;
  }

  // Total kategori
  int getCategoryCount() {

    return itemList
        .map((item) => item.kategori)
        .toSet()
        .length;
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: const Text(
          'Warehouse Notes',
        ),

        actions: [

          IconButton(
            onPressed: () {},

            icon: const Icon(
              Icons.search,
            ),
          ),
        ],
      ),

      // Tombol tambah barang
      floatingActionButton: FloatingActionButton(

        backgroundColor: const Color(0xFF5C6BC0),

        child: const Icon(Icons.add),

        onPressed: () async {

          await Navigator.push(
            context,

            MaterialPageRoute(
              builder: (context) {
                return const AddItemPage();
              },
            ),
          );

          loadItems();
        },
      ),

      body: SingleChildScrollView(

        child: Padding(
          padding: const EdgeInsets.all(16),

          child: Column(
            children: [

              // Card penjelasan aplikasi
              Card(

                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),

                child: const Padding(
                  padding: EdgeInsets.all(16),

                  child: Text(
                    'Warehouse Notes digunakan untuk mencatat dan mengelola stok barang gudang sederhana.',
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 15),

              // Statistik
              SingleChildScrollView(

                scrollDirection: Axis.horizontal,

                child: Row(
                  children: [

                    infoCard(
                      'Total Barang',
                      itemList.length.toString(),
                    ),

                    infoCard(
                      'Stok Menipis',
                      getLowStockCount().toString(),
                    ),

                    infoCard(
                      'Kategori',
                      getCategoryCount().toString(),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 15),

              // Search bar
              SearchBarWidget(
                controller: searchController,
                onChanged: searchItems,
              ),

              const SizedBox(height: 15),

              // Dropdown sorting
              DropdownButtonFormField<String>(

                value: selectedSort,

                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white,

                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),

                items: [
                    'Semua',
                    'Stok Sedikit',
                    'Elektronik',
                    'ATK',
                    'Kosmetik',
                    'Alat Sekolah',
                    'Furniture',
                    'Peralatan Kantor',
                    'Peralatan Rumah Tangga',
                    'Makanan',
                    'Minuman',
                    'Aksesoris',
                    'Peralatan Kebersihan',

                ].map((item) {

                  return DropdownMenuItem(
                    value: item,
                    child: Text(item),
                  );

                }).toList(),

                onChanged: (value) {

                  if (value != null) {
                    sortItems(value);
                  }
                },
              ),

              const SizedBox(height: 20),

              // List barang
              SizedBox(

                height: 400,

                child: filteredList.isEmpty

                    ? const Center(
                        child: Text(
                          'Belum ada data barang',
                        ),
                      )

                    : ListView.builder(

                        itemCount: filteredList.length,

                        itemBuilder: (context, index) {

                          ItemModel item =
                              filteredList[index];

                          return ItemCard(

                            item: item,

                            onEdit: () async {

                              await Navigator.push(
                                context,

                                MaterialPageRoute(
                                  builder: (context) {

                                    return EditItemPage(
                                      item: item,
                                    );
                                  },
                                ),
                              );

                              loadItems();
                            },

                            onDelete: () {
                              deleteItem(item);
                            },
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Card statistik
  Widget infoCard(
    String title,
    String value,
  ) {

    return Container(

      width: 120,
      margin: const EdgeInsets.only(right: 10),

      child: Card(

        child: Padding(
          padding: const EdgeInsets.all(12),

          child: Column(
            children: [

              Text(
                value,

                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 5),

              Text(
                title,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}