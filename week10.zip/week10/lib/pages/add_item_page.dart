import 'package:flutter/material.dart';

import '../models/item_model.dart';
import '../services/shared_pref_service.dart';

class AddItemPage extends StatefulWidget {
  const AddItemPage({super.key});

  @override
  State<AddItemPage> createState() => _AddItemPageState();
}

class _AddItemPageState extends State<AddItemPage> {

  final namaController = TextEditingController();
  final stokController = TextEditingController();
  final rakController = TextEditingController();
  final deskripsiController = TextEditingController();

  // Dropdown kategori
  String selectedCategory = 'Elektronik';

  List<String> categories = [
    'Elektronik',
    'ATK',
    'Kosmetik',
    'Alat Sekolah',
    'Furniture',
    'Peralatan Kantor',
    'Peralatan Rumah Tangga',
    'Makanan',
    'Minuman',
    'Aksesoris',
    'Peralatan Kebersihan',
  ];

  // Simpan barang
  Future<void> saveItem() async {

    List<ItemModel> items =
        await SharedPrefService.loadItems();

    ItemModel newItem = ItemModel(
      id: DateTime.now().millisecondsSinceEpoch,
      namaBarang: namaController.text,
      kategori: selectedCategory,
      stok: int.parse(stokController.text),
      lokasiRak: rakController.text,
      deskripsi: deskripsiController.text,
    );

    items.add(newItem);

    await SharedPrefService.saveItems(items);
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text('Tambah Barang'),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),

        child: SingleChildScrollView(

          child: Column(
            children: [

              // Nama barang
              TextField(
                controller: namaController,

                decoration: const InputDecoration(
                  labelText: 'Nama Barang',
                ),
              ),

              const SizedBox(height: 15),

              // Dropdown kategori
              DropdownButtonFormField<String>(

                value: selectedCategory,

                decoration: const InputDecoration(
                  labelText: 'Kategori',
                ),

                items: categories.map((category) {

                  return DropdownMenuItem(
                    value: category,
                    child: Text(category),
                  );

                }).toList(),

                onChanged: (value) {

                  setState(() {
                    selectedCategory = value!;
                  });
                },
              ),

              const SizedBox(height: 15),

              // Stok
              TextField(
                controller: stokController,
                keyboardType: TextInputType.number,

                decoration: const InputDecoration(
                  labelText: 'Stok',
                ),
              ),

              const SizedBox(height: 15),

              // Lokasi rak
              TextField(
                controller: rakController,

                decoration: const InputDecoration(
                  labelText: 'Lokasi Rak',
                ),
              ),

              const SizedBox(height: 15),

              // Deskripsi
              TextField(
                controller: deskripsiController,
                maxLines: 3,

                decoration: const InputDecoration(
                  labelText: 'Deskripsi',
                ),
              ),

              const SizedBox(height: 25),

              // Tombol simpan
              SizedBox(
                width: double.infinity,

                child: ElevatedButton(

                  onPressed: () {

                    showDialog(
                      context: context,

                      builder: (context) {

                        return AlertDialog(
                          title: const Text('Konfirmasi'),

                          content: const Text(
                            'Apakah data barang sudah benar?',
                          ),

                          actions: [

                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },

                              child: const Text('Batal'),
                            ),

                            ElevatedButton(
                              onPressed: () async {

                                await saveItem();

                                Navigator.pop(context);
                                Navigator.pop(context, true);
                              },

                              child: const Text('Simpan'),
                            ),
                          ],
                        );
                      },
                    );
                  },

                  child: const Text('Simpan Barang'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}