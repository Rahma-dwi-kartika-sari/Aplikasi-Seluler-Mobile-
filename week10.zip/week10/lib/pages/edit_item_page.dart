import 'package:flutter/material.dart';

import '../models/item_model.dart';
import '../services/shared_pref_service.dart';

class EditItemPage extends StatefulWidget {

  final ItemModel item;

  const EditItemPage({
    super.key,
    required this.item,
  });

  @override
  State<EditItemPage> createState() => _EditItemPageState();
}

class _EditItemPageState extends State<EditItemPage> {

  late TextEditingController namaController;
  late TextEditingController stokController;
  late TextEditingController rakController;
  late TextEditingController deskripsiController;

  // Dropdown kategori
  late String selectedCategory;

  List<String> categories = [
    'Elektronik',
    'ATK',
    'Kosmetik',
    'Alat Sekolah',
    'Furniture',
    'Peralatan Kantor',
    'Peralatan Rumah Tangga',
    'Makanan',
    'Minuman',
    'Aksesoris',
    'Peralatan Kebersihan',
  ];

  @override
  void initState() {
    super.initState();

    namaController = TextEditingController(
      text: widget.item.namaBarang,
    );

    stokController = TextEditingController(
      text: widget.item.stok.toString(),
    );

    rakController = TextEditingController(
      text: widget.item.lokasiRak,
    );

    deskripsiController = TextEditingController(
      text: widget.item.deskripsi,
    );

    selectedCategory = widget.item.kategori;
  }

  // Update barang
  Future<void> updateItem() async {

    List<ItemModel> items =
        await SharedPrefService.loadItems();

    int index = items.indexWhere((item) {
      return item.id == widget.item.id;
    });

    if (index != -1) {

      items[index] = ItemModel(
        id: widget.item.id,
        namaBarang: namaController.text,
        kategori: selectedCategory,
        stok: int.parse(stokController.text),
        lokasiRak: rakController.text,
        deskripsi: deskripsiController.text,
      );

      await SharedPrefService.saveItems(items);
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text('Edit Barang'),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16),

        child: SingleChildScrollView(

          child: Column(
            children: [

              // Nama barang
              TextField(
                controller: namaController,

                decoration: const InputDecoration(
                  labelText: 'Nama Barang',
                ),
              ),

              const SizedBox(height: 15),

              // Dropdown kategori
              DropdownButtonFormField<String>(

                value: selectedCategory,

                decoration: const InputDecoration(
                  labelText: 'Kategori',
                ),

                items: categories.map((category) {

                  return DropdownMenuItem(
                    value: category,
                    child: Text(category),
                  );

                }).toList(),

                onChanged: (value) {

                  setState(() {
                    selectedCategory = value!;
                  });
                },
              ),

              const SizedBox(height: 15),

              // Stok
              TextField(
                controller: stokController,
                keyboardType: TextInputType.number,

                decoration: const InputDecoration(
                  labelText: 'Stok',
                ),
              ),

              const SizedBox(height: 15),

              // Lokasi rak
              TextField(
                controller: rakController,

                decoration: const InputDecoration(
                  labelText: 'Lokasi Rak',
                ),
              ),

              const SizedBox(height: 15),

              // Deskripsi
              TextField(
                controller: deskripsiController,
                maxLines: 3,

                decoration: const InputDecoration(
                  labelText: 'Deskripsi',
                ),
              ),

              const SizedBox(height: 25),

              // Tombol save
              SizedBox(
                width: double.infinity,

                child: ElevatedButton(

                  onPressed: () {

                    showDialog(
                      context: context,

                      builder: (context) {

                        return AlertDialog(
                          title: const Text('Konfirmasi'),

                          content: const Text(
                            'Apakah perubahan ingin disimpan?',
                          ),

                          actions: [

                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },

                              child: const Text('Batal'),
                            ),

                            ElevatedButton(
                              onPressed: () async {

                                await updateItem();

                                Navigator.pop(context);
                                Navigator.pop(context, true);
                              },

                              child: const Text('Simpan'),
                            ),
                          ],
                        );
                      },
                    );
                  },

                  child: const Text('Save Perubahan'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}