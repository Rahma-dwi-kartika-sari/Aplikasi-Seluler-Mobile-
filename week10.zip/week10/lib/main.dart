import 'package:flutter/material.dart';
import 'pages/home_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();

  SharedPreferences prefs =
      await SharedPreferences.getInstance();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Warehouse Notes',

      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF3F0FA),

        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF7E57C2),
          foregroundColor: Colors.white,
          centerTitle: false,
        ),

        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7E57C2),
        ),
      ),

      home: const HomePage(),
    );
  }
}